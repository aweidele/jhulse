                                <form class="form-inline form" role="form" action="<?php echo get_home_url(); ?>">
                                    <div class="search-row">
                                        <button class="search-btn" type="submit" title="Search">
                                            <i class="fa fa-search"></i>
                                        </button>
                                        <input type="text" name="s" id="s" class="form-control" placeholder="Search...">
                                    </div>
                                </form>